# Tanisha Telecom: Gadget E-commerce Website

Storefront in plain **HTML / CSS / JavaScript**, backend + admin panel in **Laravel 13** with **MySQL**, online payments via **shurjoPay**.

| Part | Where | URL |
|------|-------|-----|
| Storefront (HTML/CSS/JS) | `public/*.html`, `public/assets/` | `/` , `/shop.html`, … |
| REST API (Laravel) | `routes/api.php`, `app/Http/Controllers/Api` | `/api/...` |
| Admin panel (Laravel Blade) | `routes/web.php`, `app/Http/Controllers/Admin`, `resources/views/admin` | `/admin` |
| shurjoPay integration | `app/Services/ShurjoPay.php`, `app/Http/Controllers/PaymentController.php` | `/payment/shurjopay/return` |

**Default admin login:** `admin@gmail.com` / `admin000`. Change it right after the first login (Admin → click your name → My Profile).

---

## Features

**Storefront:** home (banner, slider, product grid, categories), shop with category / search / price filter / sorting / pagination, product details, cart, wishlist, checkout (online payment via shurjoPay with bKash, Nagad, Rocket and cards, or Cash on Delivery, inside/outside Dhaka delivery charge), order tracking with "pay again" for failed payments, customer register/login/dashboard with order history, contact form, About / Refund / Terms pages. Mobile responsive.

**Admin panel:** dashboard (revenue, orders, 7-day sales chart, low stock, best sellers), products (image upload, sale price, stock, featured, show/hide), categories, orders (status + payment status, shurjoPay transaction details, "Verify payment with shurjoPay" button, cancelling returns stock, printable invoice), customers, contact messages, home sliders, page editor (About/Refund/Terms), site settings (name, logo, banner, phone, email, address, Facebook, WhatsApp, delivery charges, shurjoPay status).

---

## Run locally (XAMPP)

Requirements: PHP 8.3+, Composer, MySQL 5.7+ / MariaDB 10.3+ (XAMPP is fine).

1. Start **MySQL** in the XAMPP Control Panel.
2. phpMyAdmin → create a database named **`tanisha_telecom`** (collation `utf8mb4_unicode_ci`).
3. Then:

```bash
composer install
cp .env.example .env          # DB_DATABASE=tanisha_telecom, DB_USERNAME=root, DB_PASSWORD= (empty on XAMPP)
php artisan key:generate
php artisan migrate --seed    # creates tables + demo gadgets + admin user
php artisan serve
```

Open http://127.0.0.1:8000 (shop) and http://127.0.0.1:8000/admin (admin).

Instead of `migrate --seed` you can import `database/tanisha_telecom.sql` in phpMyAdmin.

---

## shurjoPay

Credentials live only in `.env` (never commit them):

```
SHURJOPAY_MODE=sandbox            # sandbox | live
SHURJOPAY_PREFIX=TTM

SHURJOPAY_SANDBOX_URL=https://sandbox.shurjopayment.com
SHURJOPAY_SANDBOX_USERNAME=sp_sandbox
SHURJOPAY_SANDBOX_PASSWORD="pyyk97hu&6u6"

SHURJOPAY_LIVE_URL=https://engine.shurjopayment.com
SHURJOPAY_LIVE_USERNAME=your_live_api_username
SHURJOPAY_LIVE_PASSWORD="your_live_api_password"
```

- **Testing:** keep `SHURJOPAY_MODE=sandbox`. On the sandbox payment page enter any card details (e.g. `4111 1111 1111 1111`, `12 / 2030`, `123`) and press **Success** or **Failed**. Test transactions are visible at https://sandbox.admin.shurjopayment.com.
- **Going live:** once shurjoPay activates your live account, set `SHURJOPAY_MODE=live`, then run `php artisan optimize:clear` (and `php artisan config:cache` on the server).
- How it works: the order is created and stock reserved → the customer is redirected to shurjoPay → shurjoPay redirects back to `/payment/shurjopay/return` (or `/cancel`) → the payment is **verified server-side** with shurjoPay before the order is marked Paid. Admins can re-check any order with **Verify payment with shurjoPay** on the order page.
- Your live site must use **HTTPS** and a public `APP_URL` so shurjoPay can redirect customers back.
- **IPN URL** (set it in the shurjoPay merchant panel): `https://your-domain.com/payment/shurjopay/ipn`. shurjoPay calls it server-to-server with `order_id`, so a payment is still recorded even if the customer closes the browser before returning to the site. The order is only updated after verifying it with shurjoPay.

---

## Deploy to cPanel

### 1. Create the database
cPanel → **MySQL® Databases**: create a database and a user, then add the user to the database with **ALL PRIVILEGES**. Note the full names (cPanel prefixes them, e.g. `cpuser_tanisha`).

### 2. Import the data
Either:
- **phpMyAdmin** → select the database → **Import** → choose `database/tanisha_telecom.sql` (demo gadgets + admin user), **or**
- **cPanel Terminal** (after step 4): `php artisan migrate --seed --force`

### 3. Prepare the files (on your PC)
```bash
composer install --no-dev --optimize-autoloader
```
Zip the whole project folder **including `vendor/`** (most cPanel hosts don't have Composer).

### 4. Upload
cPanel → **File Manager** → upload the zip to your home folder (e.g. `/home/cpuser/ecommerce`) — **not** inside `public_html` — and extract it.

Then choose one option:

**Option A (recommended): point the domain at `public/`**
cPanel → **Domains** → edit your domain → set Document Root to `/home/cpuser/ecommerce/public`.

**Option B: use `public_html`**
Move everything inside `ecommerce/public/` into `public_html/`, then edit `public_html/index.php` and change the three paths:
```php
__DIR__.'/../ecommerce/storage/framework/maintenance.php'
__DIR__.'/../ecommerce/vendor/autoload.php'
__DIR__.'/../ecommerce/bootstrap/app.php'
```
Also add this line to `.env` so uploaded images are saved into `public_html/uploads`:
```
PUBLIC_PATH=/home/cpuser/public_html
```

### 5. Edit `.env` on the server
```
APP_NAME="Tanisha Telecom"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://yourdomain.com

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=cpuser_tanisha
DB_USERNAME=cpuser_tanishauser
DB_PASSWORD=your-db-password

SHURJOPAY_MODE=live
SHURJOPAY_LIVE_USERNAME=your_live_api_username
SHURJOPAY_LIVE_PASSWORD="your_live_api_password"
```
If `APP_KEY` is empty, generate one locally with `php artisan key:generate --show` and paste it in.

### 6. Select PHP version & permissions
- cPanel → **Select PHP Version / MultiPHP Manager** → PHP **8.3 or newer**, extensions `pdo_mysql`, `mbstring`, `openssl`, `fileinfo`, `gd`, `curl`.
- Make these folders writable (755 or 775): `storage/`, `bootstrap/cache/`, `public/uploads/` (create it if missing).

### 7. (Optional, via Terminal) Optimise
```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
```
Run `php artisan optimize:clear` after changing `.env`.

---

## Notes
- Demo product, category and slider photos are in `public/assets/images`. Replace them with your real product photos from **Admin → Products / Categories / Sliders**.
- Logo, banner, phone numbers, delivery charges etc. are all editable in **Admin → Settings**.
- The storefront calls the API at `api/` (relative). To host the HTML on a different domain, change `API_BASE` in `public/assets/js/config.js`.

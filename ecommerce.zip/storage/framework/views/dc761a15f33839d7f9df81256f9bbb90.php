<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3>All categories (<?php echo e($categories->count()); ?>)</h3>
        <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add category</a>
    </div>
    <div class="card-body p-0 table-wrap">
        <table class="table">
            <thead>
            <tr><th>Image</th><th>Name</th><th>Slug</th><th>Products</th><th>Order</th><th>Status</th><th class="text-right">Actions</th></tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($category->image_url): ?>
                            <img src="<?php echo e($category->image_url); ?>" class="thumb" alt="">
                        <?php else: ?>
                            <div class="thumb" style="display:grid;place-items:center;color:#bbb"><i class="fa-solid fa-layer-group"></i></div>
                        <?php endif; ?>
                    </td>
                    <td class="fw-600"><?php echo e($category->name); ?></td>
                    <td class="text-muted"><?php echo e($category->slug); ?></td>
                    <td><a href="<?php echo e(route('admin.products.index', ['category' => $category->id])); ?>"><?php echo e($category->products_count); ?></a></td>
                    <td><?php echo e($category->sort_order); ?></td>
                    <td><span class="badge badge-<?php echo e($category->is_active ? 'active' : 'inactive'); ?>"><?php echo e($category->is_active ? 'Active' : 'Hidden'); ?></span></td>
                    <td>
                        <div class="actions">
                            <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn btn-outline btn-sm btn-icon" title="Edit"><i class="fa-solid fa-pen"></i></a>
                            <form method="POST" action="<?php echo e(route('admin.categories.destroy', $category)); ?>" data-confirm="Delete this category?">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm btn-icon" title="Delete"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7"><div class="empty-state"><i class="fa-solid fa-layer-group"></i><p>No categories yet.</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Tahsan\Downloads\New E Commerce\ecommerce\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>
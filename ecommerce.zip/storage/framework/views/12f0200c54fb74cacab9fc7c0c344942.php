<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="status-tabs" style="margin-bottom:18px">
    <a href="<?php echo e(route('admin.orders.index', request()->except('status', 'page'))); ?>" class="<?php echo e(request('status') ? '' : 'active'); ?>">
        All <span><?php echo e($counts->sum()); ?></span>
    </a>
    <?php $__currentLoopData = \App\Models\Order::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.orders.index', array_merge(request()->except('page'), ['status' => $key]))); ?>" class="<?php echo e(request('status') === $key ? 'active' : ''); ?>">
            <?php echo e($label); ?> <span><?php echo e($counts[$key] ?? 0); ?></span>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="card">
    <div class="card-header">
        <form method="GET" class="filters">
            <?php if(request('status')): ?><input type="hidden" name="status" value="<?php echo e(request('status')); ?>"><?php endif; ?>
            <input type="text" name="search" class="form-control" style="min-width:260px" placeholder="Order no, customer name or phone" value="<?php echo e(request('search')); ?>">
            <button class="btn btn-outline" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
        </form>
    </div>
    <div class="card-body p-0 table-wrap">
        <table class="table">
            <thead>
            <tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th class="text-right"></th></tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="fw-600"><?php echo e($order->order_number); ?></a></td>
                    <td><?php echo e($order->customer_name); ?><br><small class="text-muted"><?php echo e($order->phone); ?></small></td>
                    <td><?php echo e($order->items_count); ?></td>
                    <td class="fw-600"><?php echo e(money($order->total)); ?></td>
                    <td>
                        <?php echo e($order->payment_method_label); ?><br>
                        <span class="badge badge-<?php echo e($order->payment_status); ?>"><?php echo e(ucfirst($order->payment_status)); ?></span>
                    </td>
                    <td><span class="badge badge-<?php echo e($order->status); ?>"><?php echo e($order->status_label); ?></span></td>
                    <td class="text-muted"><?php echo e($order->created_at->format('d M Y')); ?><br><small><?php echo e($order->created_at->format('h:i A')); ?></small></td>
                    <td><div class="actions"><a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="btn btn-outline btn-sm">View</a></div></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8"><div class="empty-state"><i class="fa-solid fa-inbox"></i><p>No orders found.</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($orders->total()): ?>
        <div class="pagination-bar">
            <span>Showing <?php echo e($orders->firstItem()); ?>-<?php echo e($orders->lastItem()); ?> of <?php echo e($orders->total()); ?></span>
            <?php echo e($orders->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Tahsan\Downloads\New E Commerce\ecommerce\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>
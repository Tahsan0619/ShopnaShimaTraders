<?php $__env->startSection('title', 'Order '.$order->order_number); ?>

<?php $__env->startSection('content'); ?>
<div class="filters no-print" style="justify-content:space-between; margin-bottom:18px">
    <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-outline"><i class="fa-solid fa-arrow-left"></i> All orders</a>
    <div class="filters">
        <a href="<?php echo e(route('admin.orders.invoice', $order)); ?>" target="_blank" class="btn btn-outline"><i class="fa-solid fa-print"></i> Print invoice</a>
        <form method="POST" action="<?php echo e(route('admin.orders.destroy', $order)); ?>" data-confirm="Delete this order permanently?">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger"><i class="fa-solid fa-trash"></i> Delete</button>
        </form>
    </div>
</div>

<div class="grid-2">
    <div>
        <div class="card">
            <div class="card-header">
                <h3>Items</h3>
                <span class="badge badge-<?php echo e($order->status); ?>"><?php echo e($order->status_label); ?></span>
            </div>
            <div class="card-body p-0 table-wrap">
                <table class="table">
                    <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th class="text-right">Total</th></tr></thead>
                    <tbody>
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div style="display:flex;align-items:center;gap:12px">
                                    <img src="<?php echo e($item->product?->image_url ?? asset('assets/images/placeholder.jpg')); ?>" class="thumb" alt="">
                                    <div>
                                        <div class="fw-600"><?php echo e($item->product_name); ?></div>
                                        <?php if (! ($item->product)): ?><small class="text-muted">Product deleted</small><?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e(money($item->price)); ?></td>
                            <td>× <?php echo e($item->quantity); ?></td>
                            <td class="text-right fw-600"><?php echo e(money($item->total)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-body" style="border-top:1px solid var(--border)">
                <dl class="detail-list totals" style="max-width:340px;margin-left:auto">
                    <div><dt>Subtotal</dt><dd><?php echo e(money($order->subtotal)); ?></dd></div>
                    <div><dt>Delivery (<?php echo e($order->shipping_area_label); ?>)</dt><dd><?php echo e(money($order->shipping_cost)); ?></dd></div>
                    <?php if($order->discount > 0): ?>
                        <div><dt>Discount</dt><dd>-<?php echo e(money($order->discount)); ?></dd></div>
                    <?php endif; ?>
                    <div class="grand"><dt>Total</dt><dd><?php echo e(money($order->total)); ?></dd></div>
                </dl>
            </div>
        </div>

        <?php if($order->notes): ?>
            <div class="card">
                <div class="card-header"><h3>Customer note</h3></div>
                <div class="card-body"><div class="message-body"><?php echo e($order->notes); ?></div></div>
            </div>
        <?php endif; ?>
    </div>

    <div>
        <div class="card">
            <div class="card-header"><h3>Update order</h3></div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.orders.update', $order)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label>Order status</label>
                        <select name="status" class="form-control">
                            <?php $__currentLoopData = \App\Models\Order::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php if($order->status === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="help-text">Cancelling an order returns its items to stock.</div>
                    </div>
                    <div class="form-group">
                        <label>Payment status</label>
                        <select name="payment_status" class="form-control">
                            <?php $__currentLoopData = \App\Models\Order::PAYMENT_STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php if($order->payment_status === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save changes</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3>Customer</h3></div>
            <div class="card-body">
                <dl class="detail-list">
                    <div><dt>Name</dt><dd><?php echo e($order->customer_name); ?></dd></div>
                    <div><dt>Phone</dt><dd><a href="tel:<?php echo e($order->phone); ?>"><?php echo e($order->phone); ?></a></dd></div>
                    <?php if($order->email): ?><div><dt>Email</dt><dd><?php echo e($order->email); ?></dd></div><?php endif; ?>
                    <div><dt>Address</dt><dd><?php echo e($order->address); ?><?php if($order->city): ?>, <?php echo e($order->city); ?><?php endif; ?></dd></div>
                    <div><dt>Area</dt><dd><?php echo e($order->shipping_area_label); ?></dd></div>
                    <div><dt>Account</dt><dd>
                        <?php if($order->user): ?>
                            <a href="<?php echo e(route('admin.customers.show', $order->user)); ?>"><?php echo e($order->user->email); ?></a>
                        <?php else: ?>
                            Guest checkout
                        <?php endif; ?>
                    </dd></div>
                </dl>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3>Payment</h3></div>
            <div class="card-body">
                <dl class="detail-list">
                    <div><dt>Method</dt><dd><?php echo e($order->payment_method_label); ?></dd></div>
                    <?php if($order->payment_channel): ?>
                        <div><dt>Paid with</dt><dd><?php echo e($order->payment_channel); ?></dd></div>
                    <?php endif; ?>
                    <?php if($order->transaction_id): ?>
                        <div><dt>Transaction ID</dt><dd><code><?php echo e($order->transaction_id); ?></code></dd></div>
                    <?php endif; ?>
                    <?php if($order->sp_order_id): ?>
                        <div><dt>shurjoPay ID</dt><dd><code><?php echo e($order->sp_order_id); ?></code></dd></div>
                    <?php endif; ?>
                    <div><dt>Status</dt><dd><span class="badge badge-<?php echo e($order->payment_status); ?>"><?php echo e($order->payment_status_label); ?></span></dd></div>
                    <?php if($order->paid_at): ?>
                        <div><dt>Paid at</dt><dd><?php echo e($order->paid_at->format('d M Y, h:i A')); ?></dd></div>
                    <?php endif; ?>
                    <div><dt>Placed</dt><dd><?php echo e($order->created_at->format('d M Y, h:i A')); ?></dd></div>
                </dl>
                <?php if($order->sp_order_id && $order->payment_status !== 'paid'): ?>
                    <form method="POST" action="<?php echo e(route('admin.orders.verify-payment', $order)); ?>" style="margin-top:14px">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-outline btn-block" type="submit"><i class="fa-solid fa-rotate"></i> Verify payment with shurjoPay</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Tahsan\Downloads\New E Commerce\ecommerce\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>
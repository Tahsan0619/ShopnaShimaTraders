<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> | <?php echo e(\App\Models\Setting::getValue('site_name')); ?> Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Hind+Siliguri:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/admin.css')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/icon.png')); ?>">
</head>
<body>
<?php
    $unreadMessages = \App\Models\ContactMessage::where('is_read', false)->count();
    $pendingOrders = \App\Models\Order::where('status', 'pending')->count();
?>
<div class="admin-wrapper">
    <aside class="sidebar" id="sidebar">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar-brand">
            <img src="<?php echo e(asset('assets/images/icon.png')); ?>" alt="" class="brand-icon" style="object-fit:cover">
            <span><?php echo e(\App\Models\Setting::getValue('site_name')); ?><small>Admin Panel</small></span>
        </a>
        <nav>
            <div class="nav-label">Main</div>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                <i class="fa-solid fa-gauge-high"></i> Dashboard
            </a>
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="<?php echo e(request()->routeIs('admin.orders.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-bag-shopping"></i> Orders
                <?php if($pendingOrders): ?><span class="badge-count"><?php echo e($pendingOrders); ?></span><?php endif; ?>
            </a>

            <div class="nav-label">Catalog</div>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="<?php echo e(request()->routeIs('admin.products.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-box"></i> Products
            </a>
            <a href="<?php echo e(route('admin.categories.index')); ?>" class="<?php echo e(request()->routeIs('admin.categories.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-layer-group"></i> Categories
            </a>

            <div class="nav-label">People</div>
            <a href="<?php echo e(route('admin.customers.index')); ?>" class="<?php echo e(request()->routeIs('admin.customers.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-users"></i> Customers
            </a>
            <a href="<?php echo e(route('admin.messages.index')); ?>" class="<?php echo e(request()->routeIs('admin.messages.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-envelope"></i> Messages
                <?php if($unreadMessages): ?><span class="badge-count"><?php echo e($unreadMessages); ?></span><?php endif; ?>
            </a>

            <div class="nav-label">Website</div>
            <a href="<?php echo e(route('admin.sliders.index')); ?>" class="<?php echo e(request()->routeIs('admin.sliders.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-images"></i> Sliders
            </a>
            <a href="<?php echo e(route('admin.pages.index')); ?>" class="<?php echo e(request()->routeIs('admin.pages.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-file-lines"></i> Pages
            </a>
            <a href="<?php echo e(route('admin.settings.edit')); ?>" class="<?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-gear"></i> Settings
            </a>
            <a href="<?php echo e(url('/')); ?>" target="_blank">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> View Website
            </a>
        </nav>
    </aside>
    <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

    <div class="main">
        <header class="topbar">
            <div class="topbar-left">
                <button class="menu-toggle" id="menuToggle" aria-label="Toggle menu"><i class="fa-solid fa-bars"></i></button>
                <h1><?php echo $__env->yieldContent('title', 'Dashboard'); ?></h1>
            </div>
            <div class="topbar-right">
                <a href="<?php echo e(route('admin.profile.edit')); ?>" class="topbar-user" title="My profile">
                    <span class="avatar"><?php echo e(strtoupper(mb_substr(auth()->user()->name, 0, 1))); ?></span>
                    <span class="name" style="color: var(--text)"><?php echo e(auth()->user()->name); ?></span>
                </a>
                <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-outline btn-sm" type="submit"><i class="fa-solid fa-right-from-bracket"></i> Logout</button>
                </form>
            </div>
        </header>

        <main class="content">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> <?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>

<script>
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebarBackdrop');
    document.getElementById('menuToggle').addEventListener('click', () => {
        sidebar.classList.toggle('open');
        backdrop.classList.toggle('open');
    });
    backdrop.addEventListener('click', () => {
        sidebar.classList.remove('open');
        backdrop.classList.remove('open');
    });

    document.querySelectorAll('form[data-confirm]').forEach(form => {
        form.addEventListener('submit', e => {
            if (!confirm(form.dataset.confirm)) e.preventDefault();
        });
    });

    document.querySelectorAll('input[type=file][data-preview]').forEach(input => {
        input.addEventListener('change', () => {
            const box = document.getElementById(input.dataset.preview);
            const file = input.files[0];
            if (box && file) {
                box.innerHTML = '';
                const img = document.createElement('img');
                img.src = URL.createObjectURL(file);
                box.appendChild(img);
            }
        });
    });
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Tahsan\Downloads\New E Commerce\ecommerce\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>
<?php ($s = \App\Models\Setting::allValues()); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice <?php echo e($order->order_number); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Hind+Siliguri:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', 'Hind Siliguri', sans-serif; color: #222; margin: 0; padding: 40px; font-size: 14px; }
        .invoice { max-width: 780px; margin: 0 auto; }
        .head { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #f37021; padding-bottom: 18px; }
        .brand { font-size: 24px; font-weight: 700; color: #f37021; }
        .muted { color: #777; }
        h2 { margin: 0; font-size: 28px; letter-spacing: 2px; color: #444; }
        .info { display: flex; justify-content: space-between; margin: 26px 0; gap: 30px; }
        .info h4 { margin: 0 0 6px; text-transform: uppercase; font-size: 12px; color: #999; letter-spacing: 1px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #fdf0e7; text-align: left; padding: 10px; font-size: 12px; text-transform: uppercase; }
        td { padding: 10px; border-bottom: 1px solid #eee; }
        .r { text-align: right; }
        .totals { width: 300px; margin-left: auto; margin-top: 16px; }
        .totals div { display: flex; justify-content: space-between; padding: 6px 0; }
        .totals .grand { border-top: 2px solid #222; font-weight: 700; font-size: 17px; margin-top: 6px; padding-top: 10px; }
        .foot { margin-top: 50px; text-align: center; color: #888; font-size: 12px; }
        .print-btn { position: fixed; top: 16px; right: 16px; background: #f37021; color: #fff; border: 0; padding: 10px 18px; border-radius: 6px; cursor: pointer; font-size: 14px; }
        @media print { .print-btn { display: none; } body { padding: 0; } }
    </style>
</head>
<body>
<button class="print-btn" onclick="window.print()">Print</button>
<div class="invoice">
    <div class="head">
        <div>
            <div class="brand"><?php echo e($s['site_name']); ?></div>
            <div class="muted"><?php echo e($s['address']); ?><br><?php echo e($s['phone']); ?> · <?php echo e($s['email']); ?></div>
        </div>
        <div style="text-align:right">
            <h2>INVOICE</h2>
            <div class="muted">#<?php echo e($order->order_number); ?><br><?php echo e($order->created_at->format('d M Y')); ?></div>
        </div>
    </div>

    <div class="info">
        <div>
            <h4>Bill to</h4>
            <strong><?php echo e($order->customer_name); ?></strong><br>
            <?php echo e($order->phone); ?><br>
            <?php if($order->email): ?><?php echo e($order->email); ?><br><?php endif; ?>
            <?php echo e($order->address); ?><?php if($order->city): ?>, <?php echo e($order->city); ?><?php endif; ?>
        </div>
        <div style="text-align:right">
            <h4>Payment</h4>
            <?php echo e($order->payment_method_label); ?><br>
            <?php if($order->transaction_id): ?>TrxID: <?php echo e($order->transaction_id); ?><br><?php endif; ?>
            Status: <?php echo e(ucfirst($order->payment_status)); ?>

        </div>
    </div>

    <table>
        <thead><tr><th>#</th><th>Product</th><th class="r">Price</th><th class="r">Qty</th><th class="r">Total</th></tr></thead>
        <tbody>
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e($item->product_name); ?></td>
                <td class="r"><?php echo e(money($item->price)); ?></td>
                <td class="r"><?php echo e($item->quantity); ?></td>
                <td class="r"><?php echo e(money($item->total)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="totals">
        <div><span>Subtotal</span><span><?php echo e(money($order->subtotal)); ?></span></div>
        <div><span>Delivery charge</span><span><?php echo e(money($order->shipping_cost)); ?></span></div>
        <?php if($order->discount > 0): ?><div><span>Discount</span><span>-<?php echo e(money($order->discount)); ?></span></div><?php endif; ?>
        <div class="grand"><span>Total</span><span><?php echo e(money($order->total)); ?></span></div>
    </div>

    <div class="foot">Thank you for shopping with <?php echo e($s['site_name']); ?>!</div>
</div>
</body>
</html>
<?php /**PATH C:\Users\Tahsan\Downloads\New E Commerce\ecommerce\resources\views/admin/orders/invoice.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fa-solid fa-sack-dollar"></i></div>
        <div>
            <div class="label">Total Revenue</div>
            <div class="value"><?php echo e(money($stats['revenue'])); ?></div>
            <div class="sub">Today: <?php echo e(money($stats['today_revenue'])); ?></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fa-solid fa-bag-shopping"></i></div>
        <div>
            <div class="label">Total Orders</div>
            <div class="value"><?php echo e(number_format($stats['orders'])); ?></div>
            <div class="sub"><a href="<?php echo e(route('admin.orders.index', ['status' => 'pending'])); ?>"><?php echo e($stats['pending_orders']); ?> pending</a></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fa-solid fa-box"></i></div>
        <div>
            <div class="label">Products</div>
            <div class="value"><?php echo e(number_format($stats['products'])); ?></div>
            <div class="sub <?php echo e($stats['out_of_stock'] ? 'text-danger' : ''); ?>"><?php echo e($stats['out_of_stock']); ?> out of stock</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon purple"><i class="fa-solid fa-users"></i></div>
        <div>
            <div class="label">Customers</div>
            <div class="value"><?php echo e(number_format($stats['customers'])); ?></div>
            <div class="sub"><a href="<?php echo e(route('admin.messages.index')); ?>"><?php echo e($stats['unread_messages']); ?> unread messages</a></div>
        </div>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header"><h3>Sales: last 7 days</h3></div>
        <div class="card-body">
            <div class="bar-chart">
                <?php $__currentLoopData = $chart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bar-col">
                        <div class="bar" style="height: <?php echo e(max(1.5, $day['total'] / $chartMax * 85)); ?>%" title="<?php echo e($day['count']); ?> orders">
                            <?php if($day['total'] > 0): ?><span class="bar-tip"><?php echo e(money($day['total'])); ?></span><?php endif; ?>
                        </div>
                        <div class="bar-label"><?php echo e($day['label']); ?><br><?php echo e($day['date']); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h3>Orders by status</h3></div>
        <div class="card-body">
            <dl class="detail-list">
                <?php $__currentLoopData = \App\Models\Order::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <dt><span class="badge badge-<?php echo e($key); ?>"><?php echo e($label); ?></span></dt>
                        <dd><a href="<?php echo e(route('admin.orders.index', ['status' => $key])); ?>"><?php echo e($statusCounts[$key] ?? 0); ?></a></dd>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </dl>
        </div>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header">
            <h3>Recent orders</h3>
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-outline btn-sm">View all</a>
        </div>
        <div class="card-body p-0 table-wrap">
            <table class="table">
                <thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="fw-600"><?php echo e($order->order_number); ?></a></td>
                        <td><?php echo e($order->customer_name); ?><br><small class="text-muted"><?php echo e($order->phone); ?></small></td>
                        <td><?php echo e(money($order->total)); ?></td>
                        <td><span class="badge badge-<?php echo e($order->status); ?>"><?php echo e($order->status_label); ?></span></td>
                        <td class="text-muted"><?php echo e($order->created_at->format('d M, h:i A')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5"><div class="empty-state"><i class="fa-solid fa-inbox"></i><p>No orders yet.</p></div></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div>
        <div class="card">
            <div class="card-header"><h3>Low stock</h3></div>
            <div class="card-body p-0 table-wrap">
                <table class="table">
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a href="<?php echo e(route('admin.products.edit', $product)); ?>"><?php echo e($product->name); ?></a></td>
                            <td class="text-right">
                                <span class="badge <?php echo e($product->stock == 0 ? 'badge-danger' : 'badge-warning'); ?>"><?php echo e($product->stock); ?> left</span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td class="text-muted">All products are well stocked.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3>Best sellers</h3></div>
            <div class="card-body p-0 table-wrap">
                <table class="table">
                    <tbody>
                    <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->name); ?></td>
                            <td class="text-right text-muted"><?php echo e($product->sold_count); ?> sold</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Tahsan\Downloads\New E Commerce\ecommerce\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
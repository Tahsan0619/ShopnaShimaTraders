<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <form method="GET" class="filters">
            <input type="text" name="search" class="form-control" placeholder="Search products..." value="<?php echo e(request('search')); ?>">
            <select name="category" class="form-control">
                <option value="">All categories</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php if(request('category') == $cat->id): echo 'selected'; endif; ?>><?php echo e($cat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="status" class="form-control">
                <option value="">Any status</option>
                <option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>Active</option>
                <option value="inactive" <?php if(request('status') === 'inactive'): echo 'selected'; endif; ?>>Hidden</option>
                <option value="out_of_stock" <?php if(request('status') === 'out_of_stock'): echo 'selected'; endif; ?>>Out of stock</option>
            </select>
            <button class="btn btn-outline" type="submit"><i class="fa-solid fa-filter"></i> Filter</button>
            <?php if(request()->hasAny(['search', 'category', 'status'])): ?>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-outline">Reset</a>
            <?php endif; ?>
        </form>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add product</a>
    </div>
    <div class="card-body p-0 table-wrap">
        <table class="table">
            <thead>
            <tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Sold</th><th>Status</th><th class="text-right">Actions</th></tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><img src="<?php echo e($product->image_url ?? asset('assets/images/placeholder.jpg')); ?>" class="thumb" alt=""></td>
                    <td>
                        <div class="fw-600"><?php echo e($product->name); ?></div>
                        <small class="text-muted"><?php echo e($product->unit); ?></small>
                        <?php if($product->is_featured): ?><span class="badge badge-featured">Featured</span><?php endif; ?>
                    </td>
                    <td><?php echo e($product->category->name ?? '-'); ?></td>
                    <td>
                        <?php if($product->on_sale): ?>
                            <div class="fw-600"><?php echo e(money($product->sale_price)); ?></div>
                            <small class="text-muted"><s><?php echo e(money($product->price)); ?></s></small>
                        <?php else: ?>
                            <div class="fw-600"><?php echo e(money($product->price)); ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?php echo e($product->stock == 0 ? 'badge-danger' : ($product->stock <= 5 ? 'badge-warning' : 'badge-active')); ?>"><?php echo e($product->stock); ?></span>
                    </td>
                    <td><?php echo e($product->sold_count); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('admin.products.toggle', $product)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="badge badge-<?php echo e($product->is_active ? 'active' : 'inactive'); ?>" style="border:0;cursor:pointer" title="Click to toggle">
                                <?php echo e($product->is_active ? 'Active' : 'Hidden'); ?>

                            </button>
                        </form>
                    </td>
                    <td>
                        <div class="actions">
                            <a href="<?php echo e(url('product.html?slug='.$product->slug)); ?>" target="_blank" class="btn btn-outline btn-sm btn-icon" title="View"><i class="fa-solid fa-eye"></i></a>
                            <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="btn btn-outline btn-sm btn-icon" title="Edit"><i class="fa-solid fa-pen"></i></a>
                            <form method="POST" action="<?php echo e(route('admin.products.destroy', $product)); ?>" data-confirm="Delete this product?">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm btn-icon" title="Delete"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8"><div class="empty-state"><i class="fa-solid fa-box-open"></i><p>No products found.</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($products->total()): ?>
        <div class="pagination-bar">
            <span>Showing <?php echo e($products->firstItem()); ?>-<?php echo e($products->lastItem()); ?> of <?php echo e($products->total()); ?></span>
            <?php echo e($products->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Tahsan\Downloads\New E Commerce\ecommerce\resources\views/admin/products/index.blade.php ENDPATH**/ ?>
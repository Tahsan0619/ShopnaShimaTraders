<?php $__env->startSection('title', 'Sliders'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div>
            <h3>Home page slider</h3>
            <small class="text-muted">"Main" slides rotate in the large box; "Side" images stack on the right.</small>
        </div>
        <a href="<?php echo e(route('admin.sliders.create')); ?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add slide</a>
    </div>
    <div class="card-body p-0 table-wrap">
        <table class="table">
            <thead><tr><th>Image</th><th>Title</th><th>Position</th><th>Order</th><th>Status</th><th class="text-right">Actions</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><img src="<?php echo e($slider->image_url); ?>" class="thumb" style="width:110px" alt=""></td>
                    <td>
                        <div class="fw-600"><?php echo e($slider->title ?: '-'); ?></div>
                        <small class="text-muted"><?php echo e($slider->subtitle); ?></small>
                    </td>
                    <td><?php echo e(ucfirst($slider->position)); ?></td>
                    <td><?php echo e($slider->sort_order); ?></td>
                    <td><span class="badge badge-<?php echo e($slider->is_active ? 'active' : 'inactive'); ?>"><?php echo e($slider->is_active ? 'Active' : 'Hidden'); ?></span></td>
                    <td>
                        <div class="actions">
                            <a href="<?php echo e(route('admin.sliders.edit', $slider)); ?>" class="btn btn-outline btn-sm btn-icon"><i class="fa-solid fa-pen"></i></a>
                            <form method="POST" action="<?php echo e(route('admin.sliders.destroy', $slider)); ?>" data-confirm="Delete this slide?">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm btn-icon"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"><div class="empty-state"><i class="fa-solid fa-images"></i><p>No slides yet.</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Tahsan\Downloads\New E Commerce\ecommerce\resources\views/admin/sliders/index.blade.php ENDPATH**/ ?>
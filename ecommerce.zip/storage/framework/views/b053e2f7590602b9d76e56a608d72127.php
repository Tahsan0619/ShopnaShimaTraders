<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <form method="GET" class="filters">
            <input type="text" name="search" class="form-control" style="min-width:260px" placeholder="Name, email or phone" value="<?php echo e(request('search')); ?>">
            <button class="btn btn-outline" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
        </form>
        <span class="text-muted"><?php echo e($customers->total()); ?> registered customers</span>
    </div>
    <div class="card-body p-0 table-wrap">
        <table class="table">
            <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Spent</th><th>Joined</th><th class="text-right"></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-600"><?php echo e($customer->name); ?></td>
                    <td><?php echo e($customer->email); ?></td>
                    <td><?php echo e($customer->phone ?? '-'); ?></td>
                    <td><?php echo e($customer->orders_count); ?></td>
                    <td><?php echo e(money($customer->orders_total ?? 0)); ?></td>
                    <td class="text-muted"><?php echo e($customer->created_at->format('d M Y')); ?></td>
                    <td><div class="actions"><a href="<?php echo e(route('admin.customers.show', $customer)); ?>" class="btn btn-outline btn-sm">View</a></div></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7"><div class="empty-state"><i class="fa-solid fa-users"></i><p>No customers yet.</p></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($customers->hasPages()): ?>
        <div class="pagination-bar"><span></span><?php echo e($customers->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Tahsan\Downloads\New E Commerce\ecommerce\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>